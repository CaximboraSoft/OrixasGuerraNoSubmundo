function alterna(x){
    if(x===1){
        document.getElementById("home").style.display="block";
        document.getElementById("jogos").style.display="none";
        document.getElementById("sobre").style.display="none";
        document.getElementById("contato").style.display="none";
    }else if(x===2){
        document.getElementById("home").style.display="none";
        document.getElementById("jogos").style.display="block";
        document.getElementById("sobre").style.display="none";
        document.getElementById("contato").style.display="none";
    }else if(x===3){
        document.getElementById("home").style.display="none";
        document.getElementById("jogos").style.display="none";
        document.getElementById("sobre").style.display="block";
        document.getElementById("contato").style.display="none";
    }else if(x===4){
        document.getElementById("home").style.display="none";
        document.getElementById("jogos").style.display="none";
        document.getElementById("sobre").style.display="none";
        document.getElementById("contato").style.display="block";
    }
}

img = new Array('1','2','3','4');

indice = 0;

setInterval("mudaImg()", 3000);
	
function mudaImg(i) {
	if (i === 1 || i === 2 || i === 3 || i === 4) {
		indice = i;	
	} else {
		if (indice === img.length - 1) {
			indice = 0;
		} else {
			indice++;
		}	
	}
	document.getElementById("banner_img_1").setAttribute("class", "");
	document.getElementById("banner_img_2").setAttribute("class", "");
	document.getElementById("banner_img_3").setAttribute("class", "");
	document.getElementById("banner_img_4").setAttribute("class", "");
	document.getElementById("banner_img_" + img[indice]).setAttribute("class", "hover");
	document.getElementById("banner_img").innerHTML = "<img src='imagens/banner_img/"+ img[indice] +".jpg' width='800' height='368' alt='Banner'>";
}
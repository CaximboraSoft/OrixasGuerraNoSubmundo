<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>Caximbora Soft</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="Junior, Valter & Joao, Pizato">
        <link rel="stylesheet" href="css/style.css">
        <script src="js/script.js"></script>
    </head>
    <body>
        <section id="container">
            <header id="topo">
                <div id="logo">
                    <div id="social">
                        <a href="#"><img src="imagens/face.png" alt="facebook"></a>
                        <a href="#"><img src="imagens/twitter.png" alt="twitter"></a>
                        <a href="#"><img src="imagens/insta.png" alt="instagram"></a>
                        <a href="#"><img src="imagens/my.png" alt="google"></a>
                    </div>
                </div>
                <nav id="menu">
                    <ul>
                        <li><a href="javascript:alterna(1);">Home</a></li>
                        <li><a href="javascript:alterna(2);">Jogos</a></li>
                        <li><a href="javascript:alterna(3);">Sobre</a></li>
                        <li><a href="javascript:alterna(4);">Contato</a></li>
                    </ul>
                </nav>
            </header>
            <section id="principal">
                <section id="home">
                    <div id="banner">
                    <div id="banner_img">
                        <img src="imagens/banner_img/1.jpg" alt="Banner" width="800" height="368">
                        <img id="b1" src="imagens/banner_img/3.jpg" alt="Banner" width="800" height="368">
                        <img id="b2" src="imagens/banner_img/4.jpg" alt="Banner" width="800" height="368">
                    </div>
                    <nav id="botoes">
                        <a href="javascript:void(0);" id="banner_img_1" class="hover" onclick="mudaImg('1');">1</a>
                        <a href="javascript:void(0);" id="banner_img_2" class="hover" onclick="mudaImg('2');">2</a>
                        <a href="javascript:void(0);" id="banner_img_3" class="hover" onclick="mudaImg('3');">3</a>
                        <a href="javascript:void(0);" id="banner_img_4" class="hover" onclick="mudaImg('4');">4</a>
                    </nav>
                </div>
                </section>
                <section id="jogos">
                    <section id="quadro_jogos">
                        <nav id="text_jogos">
                            <br>
                            <br>
                            <ul>
                                <li><b>JOGOS</b></li><BR>
                                <li>THE TOKEONS OF ORIXÁS<a href="#">LINK INDISPONÍVEL</a></li><br>
                                <li>ORIXÁS: GUERRA DOS MUNDOS<a href="#"><b><u>JOGUE AGORA!</u></b></a></li><br>
                                <li>ORIXÁS REVENGE<a href="#">  LINK INDISPONÍVEL</a></li><br>
                                <li>ORIXÁS: GUERRA NO SUBMUNDO<a href="#">APARTIR DE 25/06/2018</a></li><br>
                  
                            </ul>
                            <br>
                            © Caximbora Soft. - Todos os direitos reservados.
                        </nav>
                    </section>
                </section>
                <section id="sobre">
                    <img id="logo_sobre" src="imagens/logo2.png" alt="Ilha dos Doces">
                    <article id="text_sobre">
                        <br>
                        <h1>Missão</h1><br/>
                        A Caximbora Soft é uma futura empresa formada pela junção de integrantes do Curso Superior de Jogos
                        Digitais da Faculdade de Tecnologia de Carapicuíba. Com o objetivo de se unirem em busca de
                        seus sonhos no desenvolvimento de Jogos Digitais.<br>
                        <br>
                        João Pizato<br>
                        Matheus Souza<br>
                        Lucas Nascimento<br>
                        Rodrigo Fernando<br>
                        Valter Jorge<br>
                        <br>
                        © Caximbora Soft. - Todos os direitos reservados.
                    </article>
                </section>
                <section id="contato">
                    <div id="quadro_contato">
                        <div id="area">
                            <form action="verifica.php" method="POST" id="formulario" autocomplete="off">
                            <fieldset>
                            <legend>Contate-nos</legend>
                            <label>Nome:</label><input class="campo_nome" type="text"name="nome"><br>
                            <label>Email:</label><input class="campo_email" type="text" name="email"><br>
                            <label>Mensagem:</label><br><textarea class="msg" cols="40" rows="8" name="comentarios"></textarea><br>
                            <input class="btn_submit" type="submit" value="Enviar">
                            </fieldset>
                            </form>
                        </div>
                    </div>
                </section>
            </section>
            <footer id="rodape">
                <div id="direitos">© Caximbora Soft. - Todos os direitos reservados.</div>
            </footer>
        </section>
    </body>
</html>
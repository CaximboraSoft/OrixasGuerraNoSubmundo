<html>
    <body>
        
        <?php
        $nome           =    $_POST["nome"];
        $email          =    $_POST['email'];
        $comentarios    =    $_POST["comentarios"];
        $erro = 0;
        
        
        if (empty($nome) OR strstr ($nome, ' ')==FALSE){
        echo "Favor digitar seu nome completo. <br>";
        echo"<a href=\"http://localhost/caximbora/index.php\"> Clique para fechar<a/>";
        include 'index.php';
        $erro=1;}
        
        if (strlen($email)<8 || strstr ($email, '@')==FALSE){
        echo "Favor digitar um e-mail válido.<br>";
        echo"<a href=\"http://localhost/caximbora/index.php\"> Clique para fechar<a/>";
        include 'index.php';
        $erro=1;}
        
        if (empty($comentarios)){
        echo "Favor entre com algum comentário. <br>";
        echo"<a href=\"http://localhost/caximbora/index.php\"> Clique para fechar<a/>";
        include 'index.php';
        $erro=1;}
        
        
        if ($erro == 0){
        echo "Dados inseridos com sucesso.";
        include 'insere.inc';
        echo"<a href=\"http://localhost/caximbora/index.php\"> Clique para fechar<a/>";
        include 'index.php';
        }
        ?>
    </body>
</html>

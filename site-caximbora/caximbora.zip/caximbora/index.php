<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>Caximbora Soft</title>
        <meta charset="UTF-8"> <!--ISO 8859-1-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="Junior, Valter & Joao, Pizato">
        <!--<meta name="language" content="pt-br">-->
        <link rel="stylesheet" href="css/style.css">
        <script src="js/script.js"></script>
    </head>
    <body>
        <section id="container">
            <header id="topo">
                <div id="logo">
                    <div id="social">
                        <a href="www.facebook.com/"><img src="imagens/face.png" alt="facebook"></a>
                        <a href="www.twitter.com/"><img src="imagens/twitter.png" alt="twitter"></a>
                        <a href="www.instagram.com/"><img src="imagens/insta.png" alt="instagram"></a>
                        <a href="................../"><img src="imagens/my.png" alt="google"></a>
                    </div>
                </div>
                <nav id="menu">
                    <ul>
                        <li><a href="javascript:alterna(1);">Home</a></li>
                        <li><a href="javascript:alterna(2);">Jogos</a></li>
                        <li><a href="javascript:alterna(3);">Sobre</a></li>
                        <li><a href="javascript:alterna(4);">Contato</a></li>
                    </ul>
                </nav>
            </header>
            <section id="principal">
                <section id="home">
                    conteúdo 1
                </section>
                <section id="jogos">
                    conteúdo 2
                </section>
                <section id="sobre">
                    conteúdo 3
                </section>
                <section id="contato">
                    <form action="verifica.php" method="POST">
                        <pre>
                            Insira seu nome e sua mensagem.

                            Nome: <input type="text" size="35" maxlength="256" name="nome">

                            Menssagem:

                            <textarea rows="5" cols="42" name="comentarios"></textarea>

                            <input type="submit" value="Enviar" name="enviar">
                        </pre>
                    </form>
                </section>
            </section>
            <footer id="rodape">
                <div id="direitos">© Caximbora Soft. - Todos os direitos reservados.</div>
            </footer>
        </section>
    </body>
</html>
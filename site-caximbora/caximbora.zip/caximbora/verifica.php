<html>
    <body>
        
        <?php
        $nome = $_POST["nome"];
        $comentarios = $_POST["comentarios"];
        $erro = 0;
        
        
        if (empty($nome) OR strstr ($nome, ' ')==FALSE){
        echo "Favor digitar seu nome completo. <br>";
        $erro=1;}
        
        if (empty($comentarios))
        {echo "Favor entre com algum comentário. <br>";
        $erro=1;}
        
        
        
        
        if ($erro == 0){
        echo " Dados inseridos com sucesso.";
        include 'insere.inc';
        
        }
        ?>
    </body>
</html>
